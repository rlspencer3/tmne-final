---
_archived: false
song-number: "04"
_draft: false
created-on: "2020-12-28T18:28:19.772Z"
name: "OffWhitePimp"
slug: "adipisci"
updated-on: "2020-12-31T00:19:07.365Z"
image:
  url: "https://uploads-ssl.webflow.com/5ff53fee05351a19c7ee0dff/5ff53fee05351a7ab9ee0e03_1609180098389-image4.jpg"
  alt: ""
published-on: "2021-01-05T02:14:42.315Z"
song-length: "1:34"
tags: "songs"
layout: "single-songs.html"
---


