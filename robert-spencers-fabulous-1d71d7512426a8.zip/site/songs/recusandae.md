---
_archived: false
song-number: "01"
_draft: false
created-on: "2020-12-28T18:28:19.874Z"
name: "Way Too Much"
slug: "recusandae"
updated-on: "2020-12-31T00:18:25.936Z"
image:
  url: "https://uploads-ssl.webflow.com/5ff53fee05351a19c7ee0dff/5ff53fee05351a0f94ee0e05_1609180098695-image8.jpg"
  alt: ""
published-on: "2021-01-05T02:14:42.315Z"
song-length: "1:48"
tags: "songs"
layout: "single-songs.html"
---


